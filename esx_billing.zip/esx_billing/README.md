# esx_billing

Original Creator: indilo53 AKA GiZz 
Edited Creator: KennyNA

By no means is this resource created by me, I have just edited it so that modders can no longer fine your whole server - KennyNA <3